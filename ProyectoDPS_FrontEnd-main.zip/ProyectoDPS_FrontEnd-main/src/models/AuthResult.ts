import type { User } from './User';

export interface AuthCredentials {
  identifier: string;
  password: string;
}

export type AuthResult =
  | {
    success: true;
    user: User;
  }
  | {
    success: false;
    message: string;
  };
