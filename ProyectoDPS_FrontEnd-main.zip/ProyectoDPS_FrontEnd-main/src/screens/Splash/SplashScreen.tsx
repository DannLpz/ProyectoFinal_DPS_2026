import { StatusBar } from 'expo-status-bar';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { AppLogo } from '../../components/common/AppLogo';
import { ScreenContainer } from '../../components/common/ScreenContainer';
import { appConfig } from '../../config/appConfig';
import { theme } from '../../config/theme';

export function SplashScreen() {
  return (
    <ScreenContainer
      backgroundColor={theme.colors.primary}
      contentContainerStyle={styles.content}
      scrollable={false}
    >
      <StatusBar style="light" />
      <View style={styles.topDecoration} />
      <View style={styles.bottomDecoration} />

      <View style={styles.brandBlock}>
        <View style={styles.logoHalo}>
          <AppLogo variant="light" />
        </View>
        <Text style={styles.tagline}>{appConfig.tagline}</Text>
      </View>

      <View
        accessibilityLabel="Inicializando la aplicación"
        accessibilityLiveRegion="polite"
        accessibilityRole="progressbar"
        style={styles.loadingBlock}
      >
        <ActivityIndicator color={theme.colors.cream} size="small" />
        <Text style={styles.loadingText}>Preparando tu experiencia</Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    padding: theme.spacing.lg,
  },
  topDecoration: {
    backgroundColor: 'rgba(247, 234, 214, 0.10)',
    borderRadius: theme.radii.pill,
    height: 280,
    position: 'absolute',
    pointerEvents: 'none',
    right: -145,
    top: -100,
    width: 280,
  },
  bottomDecoration: {
    borderColor: 'rgba(247, 234, 214, 0.12)',
    borderRadius: theme.radii.pill,
    borderWidth: 42,
    bottom: -145,
    height: 310,
    left: -160,
    position: 'absolute',
    pointerEvents: 'none',
    width: 310,
  },
  brandBlock: {
    alignItems: 'center',
    gap: theme.spacing.lg,
    marginBottom: theme.spacing.xxxl,
  },
  logoHalo: {
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderColor: 'rgba(255, 255, 255, 0.13)',
    borderRadius: theme.radii.xl,
    borderWidth: 1,
    justifyContent: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
  },
  tagline: {
    ...theme.typography.body,
    color: theme.colors.cream,
    maxWidth: 300,
    textAlign: 'center',
  },
  loadingBlock: {
    alignItems: 'center',
    bottom: theme.spacing.xxl,
    gap: theme.spacing.sm,
    position: 'absolute',
  },
  loadingText: {
    ...theme.typography.caption,
    color: theme.colors.cream,
  },
});
