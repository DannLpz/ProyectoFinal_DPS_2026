import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { AppLogo } from '../../components/common/AppLogo';
import { ScreenContainer } from '../../components/common/ScreenContainer';
import { AppButton } from '../../components/ui/AppButton';
import { FormTextInput } from '../../components/ui/FormTextInput';
import { appConfig } from '../../config/appConfig';
import { theme } from '../../config/theme';
import { useAuth } from '../../hooks/useAuth';
import type { User } from '../../models/User';

type LoginScreenProps = {
  onAuthenticated: (user: User) => void;
};

export function LoginScreen({ onAuthenticated }: LoginScreenProps) {
  const auth = useAuth({ onAuthenticated });

  const handleSubmit = () => {
    void auth.submit();
  };

  return (
    <ScreenContainer contentContainerStyle={styles.screenContent}>
      <StatusBar style="dark" />
      <View style={styles.topDecoration} />
      <View style={styles.sideDecoration} />

      <View style={styles.content}>
        <View style={styles.brandSection}>
          <AppLogo />
          <Text style={styles.brandTagline}>{appConfig.tagline}</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>Bienvenido a LOOka</Text>
          <Text style={styles.subtitle}>
            Ingresa para descubrir cómo se verá tu próximo espacio.
          </Text>

          <View style={styles.form}>
            <FormTextInput
              autoCapitalize="none"
              autoComplete="username"
              editable={!auth.isSubmitting}
              error={auth.errors.identifier}
              icon="user"
              keyboardType="email-address"
              label="Usuario"
              onChangeText={auth.setIdentifier}
              placeholder="Ingresa tu usuario"
              returnKeyType="next"
              textContentType="username"
              value={auth.identifier}
            />
            <FormTextInput
              autoCapitalize="none"
              autoComplete="current-password"
              editable={!auth.isSubmitting}
              error={auth.errors.password}
              icon="lock"
              isPassword
              isPasswordVisible={auth.isPasswordVisible}
              label="Contraseña"
              onChangeText={auth.setPassword}
              onSubmitEditing={handleSubmit}
              onTogglePassword={auth.togglePasswordVisibility}
              placeholder="Tu contraseña"
              returnKeyType="done"
              textContentType="password"
              value={auth.password}
            />

            {auth.generalError ? (
              <View
                accessibilityLiveRegion="assertive"
                style={styles.errorBanner}
              >
                <Feather color={theme.colors.error} name="alert-circle" size={19} />
                <Text style={styles.errorBannerText}>
                  {auth.generalError}
                </Text>
              </View>
            ) : null}

            <AppButton
              disabled={auth.isSubmitting}
              label={auth.isSubmitting ? 'Verificando...' : 'Iniciar sesión'}
              loading={auth.isSubmitting}
              onPress={handleSubmit}
              showArrow
            />
          </View>

          <View style={styles.demoBox}>
            <View style={styles.demoHeader}>
              <View style={styles.demoIcon}>
                <Feather color={theme.colors.primary} name="key" size={17} />
              </View>
              <View style={styles.demoCopy}>
                <Text style={styles.demoTitle}>Acceso de demostración</Text>
                <Text style={styles.demoCredentials}>
                  {appConfig.demoCredentials.username} ·{' '}
                  {appConfig.demoCredentials.password}
                </Text>
              </View>
              <Pressable
                accessibilityLabel="Completar credenciales de demostración"
                accessibilityRole="button"
                disabled={auth.isSubmitting}
                onPress={auth.fillDemoCredentials}
                style={({ pressed }) => [
                  styles.demoAction,
                  pressed && styles.demoActionPressed,
                ]}
              >
                <Text style={styles.demoActionText}>Completar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  screenContent: {
    overflow: 'hidden',
  },
  topDecoration: {
    backgroundColor: theme.colors.primarySoft,
    borderRadius: theme.radii.pill,
    height: 260,
    position: 'absolute',
    pointerEvents: 'none',
    right: -130,
    top: -130,
    width: 260,
  },
  sideDecoration: {
    borderColor: theme.colors.creamDark,
    borderRadius: theme.radii.pill,
    borderWidth: 35,
    height: 220,
    left: -150,
    position: 'absolute',
    pointerEvents: 'none',
    top: 250,
    width: 220,
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100%',
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.xl,
  },
  brandSection: {
    alignItems: 'center',
    gap: theme.spacing.xs,
    marginBottom: theme.spacing.lg,
  },
  brandTagline: {
    ...theme.typography.caption,
    color: theme.colors.textMuted,
    textAlign: 'center',
  },
  card: {
    ...theme.shadows.card,
    backgroundColor: theme.colors.surface,
    borderColor: theme.colors.border,
    borderRadius: theme.radii.xl,
    borderWidth: 1,
    maxWidth: theme.layout.maxFormWidth,
    padding: theme.spacing.lg,
    width: '100%',
  },
  phasePill: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: theme.colors.primarySoft,
    borderRadius: theme.radii.pill,
    flexDirection: 'row',
    gap: theme.spacing.xs,
    marginBottom: theme.spacing.md,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: 6,
  },
  statusDot: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.radii.pill,
    height: 7,
    width: 7,
  },
  phasePillText: {
    color: theme.colors.primary,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  title: {
    ...theme.typography.title,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    ...theme.typography.body,
    color: theme.colors.textMuted,
    marginBottom: theme.spacing.lg,
  },
  form: {
    gap: theme.spacing.md,
  },
  errorBanner: {
    alignItems: 'flex-start',
    backgroundColor: '#FDECEA',
    borderRadius: theme.radii.md,
    flexDirection: 'row',
    gap: theme.spacing.xs,
    padding: theme.spacing.sm,
  },
  errorBannerText: {
    ...theme.typography.caption,
    color: theme.colors.error,
    flex: 1,
  },
  demoBox: {
    backgroundColor: theme.colors.cream,
    borderRadius: theme.radii.md,
    marginTop: theme.spacing.lg,
    padding: theme.spacing.sm,
  },
  demoHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    gap: theme.spacing.sm,
  },
  demoIcon: {
    alignItems: 'center',
    backgroundColor: theme.colors.white,
    borderRadius: theme.radii.sm,
    height: 38,
    justifyContent: 'center',
    width: 38,
  },
  demoCopy: {
    flex: 1,
  },
  demoTitle: {
    ...theme.typography.caption,
    color: theme.colors.text,
    fontWeight: '700',
  },
  demoCredentials: {
    color: theme.colors.brown,
    fontSize: 12,
    fontWeight: '700',
  },
  demoAction: {
    borderRadius: theme.radii.sm,
    paddingHorizontal: theme.spacing.xs,
    paddingVertical: theme.spacing.xs,
  },
  demoActionPressed: {
    backgroundColor: theme.colors.creamDark,
  },
  demoActionText: {
    color: theme.colors.primary,
    fontSize: 12,
    fontWeight: '800',
  },
  localNotice: {
    alignItems: 'flex-start',
    flexDirection: 'row',
    gap: theme.spacing.xs,
    justifyContent: 'center',
    marginTop: theme.spacing.md,
  },
  localNoticeText: {
    color: theme.colors.textMuted,
    flexShrink: 1,
    fontSize: 11,
    lineHeight: 16,
  },
});
