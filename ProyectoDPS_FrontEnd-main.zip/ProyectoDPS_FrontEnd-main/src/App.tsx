import { StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { theme } from './config/theme';
import { useAppFlow } from './hooks/useAppFlow';
import { LoginScreen } from './screens/Auth/LoginScreen';
import { HomeScreen } from './screens/Home/HomeScreen';
import { SplashScreen } from './screens/Splash/SplashScreen';

export default function App() {
  return (
    <SafeAreaProvider>
      <AppContent />
    </SafeAreaProvider>
  );
}

function AppContent() {
  const appFlow = useAppFlow();

  if (appFlow.currentScreen === 'splash') {
    return <SplashScreen />;
  }

  if (appFlow.currentScreen === 'home' && appFlow.currentUser) {
    return (
      <HomeScreen
        onSignOut={appFlow.signOut}
        user={appFlow.currentUser}
      />
    );
  }

  return (
    <View style={styles.app}>
      <LoginScreen onAuthenticated={appFlow.completeAuthentication} />
    </View>
  );
}

const styles = StyleSheet.create({
  app: {
    backgroundColor: theme.colors.background,
    flex: 1,
  },
});
